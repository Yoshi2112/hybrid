/***************************************************************
 * Name:      [FILENAME_PREFIX]App.cpp
 * Purpose:   Code for Application Class
 * Author:    [AUTHOR_NAME] ([AUTHOR_EMAIL])
 * Created:   [NOW]
 * Copyright: [AUTHOR_NAME] ([AUTHOR_WWW])
 * License:
 **************************************************************/

[PCH_INCLUDE]#include "[FILENAME_PREFIX]App.h"

//(*AppHeaders
//*)

IMPLEMENT_APP([CLASS_PREFIX]App);

bool [CLASS_PREFIX]App::OnInit()
{
    //(*AppInitialize
    //*)
    return wxsOK;

}
