****************************
About

Code::Blocks is a free, open-source, cross-platform Integrated Development Environment
(IDE)  built to meet the most demanding needs of its users. 
Code::Blocks for Fortran is a customized version of IDE to make it more friendly for users
of Fortran.

More information on: http://cbfortran.sourceforge.net and http://www.codeblocks.org

****************************
Features useful for Fortran:

    * Editor with Fortran syntax highlighting (fixed and free form).

    * Compilation of Fortran project directly from IDE. FortranProject plugin should care
    about Fortran file dependencies. Alternatively you can use your supplied makefile.

    * Possibility to jump directly to the code line with an error (currently the support
    of gfortran, g95, Intel Fortran, Oracle Solaris Studio Fortran and PGI Fortran is
    implemented).

    * Symbols browser with defined program units (functions, subroutines, modules etc.)
    in your project.

    * Possibility to jump to code line with subroutine/function definition directly from
    editor (right click on the name and select  "Jump to: 'name'") or from the symbols
    browser (double click on the name) or using menu 'Fortran->Jump->Jump to declaration'.

    * Program debugging using GNU GDB.

    * Completion of names when you type or when you press Ctrl+Space (you can change the
    key combinations in Editor's Settings).  The support for subroutine/function names,
    the names of variables, the components of derived types and the type-bound procedures
    is implemented.

    * Call-tips with subroutine/function argument list. Appears automatically or when you
    press Ctrl+Shift+Space.

    * Appearance of tooltips when you hold mouse on variable or name of subroutine.

    * Possibility to generate a Makefile (Fortran->Genarate Makefile). This feature
    should generate a working makefile for the active target in simple cases. Or the
    generated makefile can be used as a draft in more sophisticated projects.
	
    * BindTo tool (Fortran->BindTo), which generates a wrapper code to call Fortran
    from C or Python language.

    * and more
    
****************************
Licensing

Code::Blocks is distributed under the GPL v3.0 license which means it can be used freely
by anyone! The only exception is the SDK which is allowed to be linked by closed-source
plugins.

****************************
How to start?

*Windows

Download CodeBlocks_Fortran_***_Win.zip file. Unarchive it. 
Double click on "codeblocks.exe".

For compilation a Fortran compiler is required. You may use GCC (witch includes GFortran) 
from http://tdm-gcc.tdragon.net/

*Linux

Dependencies: GTK2, xterm (make sure you have installed it) and Fortran compiler.
Download CodeBlocks_Fortran_***_Linux***.tar.bz2 file. Unarchive it. 
Open terminal in CodeBlocks_Fortran_***_Linux*** directory. 
Execute "codeblocks_run.sh" script.

****************************
Have questions? Found a bug?

Visit: http://cbfortran.sourceforge.net

Write to the CBFortran Google Group:
https://groups.google.com/forum/#!forum/cbfortran


***************************